package tests;

import hooks.BaseTests;
import org.testng.annotations.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class CreateLead extends BaseTests {

	@Test
	public void createLead() throws InterruptedException {
		getDriver().findElement(By.linkText("Leads")).click();
		getDriver().findElement(By.linkText("Create Lead")).click();
		getDriver().findElement(By.id("createLeadForm_companyName")).sendKeys("TestLeaf");
		getDriver().findElement(By.id("createLeadForm_firstName")).sendKeys("Babu");
		getDriver().findElement(By.id("createLeadForm_lastName")).sendKeys("Manickam");
		WebElement source = getDriver().findElement(By.id("createLeadForm_dataSourceId"));
		Select dd1 = new Select(source);
		dd1.selectByVisibleText("Employee");
		WebElement marketing = getDriver().findElement(By.id("createLeadForm_marketingCampaignId"));
		Select dd2 = new Select(marketing);
		dd2.selectByValue("9001");
		getDriver().findElement(By.name("submitButton")).click();

	}
}
