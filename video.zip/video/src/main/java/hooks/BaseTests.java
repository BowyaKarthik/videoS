package hooks;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.events.EventFiringDecorator;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import utils.GenerateVideo;
import listeners.ScreenshotListener;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class BaseTests {

	private static ThreadLocal<WebDriver> driver = new ThreadLocal<>();
	protected String screenshotDir;

	@BeforeMethod
	public void setUp() throws IOException, InterruptedException, Exception {

		// Create time stamped folder
		String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
		long threadId = Thread.currentThread().getId();
		screenshotDir = "screenshots/" + timestamp + "_thread" + threadId;
		new File(screenshotDir).mkdirs();

		// Launch and Login
		ChromeDriver chromeDriver = new ChromeDriver();
		ScreenshotListener screenshotListener = new ScreenshotListener(chromeDriver, screenshotDir);
		EventFiringDecorator<WebDriver> eventFiringDecorator = new EventFiringDecorator<>(screenshotListener);
		driver.set(eventFiringDecorator.decorate(chromeDriver));
		getDriver().get("http://leaftaps.com/opentaps");
		getDriver().manage().window().maximize();
		getDriver().findElement(By.id("username")).sendKeys("Demosalesmanager");
		getDriver().findElement(By.id("password")).sendKeys("crmsfa");
		getDriver().findElement(By.className("decorativeSubmit")).click();
		getDriver().findElement(By.linkText("CRM/SFA")).click();


	}

	@AfterMethod
	public void tearDown() {
		if (getDriver() != null) {
			getDriver().quit();
		}

		try {
			GenerateVideo.saveVideo(screenshotDir, this.getClass().getSimpleName());
		} catch (IOException | InterruptedException e) {
			e.printStackTrace();
		}
	}

	public WebDriver getDriver() {
		return driver.get();
	}
}
