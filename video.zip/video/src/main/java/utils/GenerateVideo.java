package utils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class GenerateVideo {

    public static void saveVideo(String screenshotDir, String testName) throws IOException, InterruptedException {
        String imagePattern = screenshotDir + "/%d.png";
        String command = "/usr/local/bin/ffmpeg -framerate 1 -i " + imagePattern + " -c:v libx264 -r 30 -pix_fmt yuv420p " + "videos/" + testName + ".mp4";

        Process process = Runtime.getRuntime().exec(command);
        BufferedReader stdError = new BufferedReader(new InputStreamReader(process.getErrorStream()));

        int exitCode = process.waitFor();
        if (exitCode == 0) {
            System.out.println("Video created successfully.");
        } else {
            System.out.println("Failed to create video. Exit code: " + exitCode);
            String s;
            while ((s = stdError.readLine()) != null) {
                System.out.println(s);
            }
        }
    }
}
