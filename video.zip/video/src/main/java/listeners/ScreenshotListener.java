package listeners;

import org.openqa.selenium.*;
import org.openqa.selenium.support.events.WebDriverListener;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;

public class ScreenshotListener implements WebDriverListener {

    private int i = 1;
    private String screenshotDir;
    private WebDriver driver;

    public ScreenshotListener(WebDriver driver, String screenshotDir) {
        this.driver = driver;
    	this.screenshotDir = screenshotDir;
    }

    private void takeScreenshot() {
        File srcFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        try {
            ImageIO.write(ImageIO.read(srcFile), "png", new File(screenshotDir + "/" + (i++) + ".png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void afterAnyCall(Object target, Method method, Object[] args, Object result) {
        try {
			takeScreenshot();
		} catch (Exception e) {
		}
    }

    @Override
    public void afterAccept(Alert alert) {
        takeScreenshot();
    }

    @Override
    public void afterDismiss(Alert alert) {
        takeScreenshot();
    }
}
