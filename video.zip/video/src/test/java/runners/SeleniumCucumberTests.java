package runners;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(glue={"pages","hooks"}, 
				features = "src/test/java/features", 
				monochrome = true,    
				plugin = {"pretty", "html:target/cucumber-reports.html"} )
public class SeleniumCucumberTests extends AbstractTestNGCucumberTests{

}
