package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import hooks.BaseTests;
import io.cucumber.java.en.When;

public class CreateLead extends BaseTests{
	
	@When("Mandatory Fields are typed with {string}, {string}, {string}, {string}, {string}")
	public CreateLead enterMandatoryFields(String company, String firstName, String lastName,
			String sourceType, String marketingType) {
		getDriver().findElement(By.id("createLeadForm_companyName")).sendKeys(company);
		getDriver().findElement(By.id("createLeadForm_firstName")).sendKeys(firstName);
		getDriver().findElement(By.id("createLeadForm_lastName")).sendKeys(lastName);
		WebElement source = getDriver().findElement(By.id("createLeadForm_dataSourceId"));
		Select dd1 = new Select(source);
		dd1.selectByVisibleText(sourceType);
		WebElement marketing = getDriver().findElement(By.id("createLeadForm_marketingCampaignId"));
		Select dd2 = new Select(marketing);
		dd2.selectByValue(marketingType);
		return this;
	}
	
	@When("Submit Button is Clicked")
	public CreateLead clickSubmit() {
		getDriver().findElement(By.name("submitButton")).click();
		return this;
	}
	

}
