package pages;

import org.openqa.selenium.By;
import hooks.BaseTests;
import io.cucumber.java.en.When;

public class Leads extends BaseTests{
	
	@When("Leads Tab is Clicked")
	public Leads clickLeads() {
		getDriver().findElement(By.linkText("Leads")).click();
		return this;
	}
	
	@When("Create Lead Link is Clicked")
	public CreateLead clickCreateLead() {
		getDriver().findElement(By.linkText("Create Lead")).click();
		return new CreateLead();
	}
	

}
