package hooks;

import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import utils.GenerateVideo;
import java.io.IOException;
import io.cucumber.java.After;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

public class CucumberHooks extends BaseTests {

    private static ConcurrentHashMap<String, AtomicInteger> scenarioCounts = new ConcurrentHashMap<>();

	@Before
	public void setUp() throws IOException, InterruptedException, Exception  {
		super.setUp();
	}

	@After
	public void tearDown(Scenario scenario) {
		if (getDriver() != null) {
			getDriver().quit();
		}

		// Get the scenario count and increment it
		String scenarioName = scenario.getName().replaceAll(" ", "_");
		scenarioCounts.putIfAbsent(scenarioName, new AtomicInteger(0));
		int count = scenarioCounts.get(scenarioName).incrementAndGet();

		try {
			GenerateVideo.saveVideo(screenshotDir, scenarioName + "_" + count);
		} catch (IOException | InterruptedException e) {
			e.printStackTrace();
		}
	}
}
